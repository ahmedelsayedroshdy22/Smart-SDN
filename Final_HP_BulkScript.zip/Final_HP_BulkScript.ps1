﻿# =====================================================
# AudioCodes SBC - Bulk Create User via REST API
# =====================================================

# CSV Format:
#
# Device Name,IP
# SBC01,192.168.1.10
# SBC02,192.168.1.11
#

# ----------------------------
# Configuration
# ----------------------------

$CsvFile = ".\HP_DataFinal.csv"

$ApiUser     = "puso7259"
$ApiPassword = "Rw49iuMzJm"

$NewUsername = "TestUserHP3333" #change the username to HP one 
$NewPassword = "12345"          #change the password to the desired one

# ----------------------------
# Authentication
# ----------------------------

$cred = "$ApiUser`:$ApiPassword"

$cred_encoded = [Convert]::ToBase64String(
    [Text.Encoding]::ASCII.GetBytes($cred)
)

# ----------------------------
# Logging Setup
# ----------------------------

$Timestamp = Get-Date -Format "yyyyMMdd_HHmmss"

$LogFolder = ".\Logs"
$ReportFile = ".\Summary_$Timestamp.csv"

New-Item -ItemType Directory `
    -Path $LogFolder `
    -Force | Out-Null

# ----------------------------
# Load Devices
# ----------------------------

$Devices = Import-Csv $CsvFile

$Results = @()

Write-Host ""
Write-Host "==========================================" -ForegroundColor Cyan
Write-Host " AudioCodes Bulk User Creation"
Write-Host "==========================================" -ForegroundColor Cyan
Write-Host "Devices Found : $($Devices.Count)"
Write-Host ""

# ----------------------------
# Process Each Device
# ----------------------------

foreach ($Device in $Devices)
{
    $DeviceName = $Device.'Device Name'
    $IP         = $Device.IP

    Write-Host ""
    Write-Host "[$DeviceName] Processing $IP" -ForegroundColor Yellow

    $LogFile = Join-Path `
        $LogFolder `
        "$DeviceName.log"

    try
    {
        # ----------------------------
        # Connectivity Check
        # ----------------------------

        if (-not (Test-Connection -ComputerName $IP -Count 1 -Quiet))
        {
            throw "Device is unreachable."
        }

        # ----------------------------
        # Build CLI Script
        # ----------------------------

        $cliScript = @"
configure system
user $NewUsername
privilege Monitor
status valid
password-age 0
password $NewPassword
exit
"@

        $CliFile = Join-Path `
            $env:TEMP `
            "$DeviceName.cli"

        $cliScript | Set-Content `
            -Path $CliFile `
            -Encoding Ascii

        # ----------------------------
        # Create User
        # ----------------------------

        Write-Host "[$DeviceName] Creating user..." -ForegroundColor Cyan

        $CreateResponse = curl.exe `
            -s `
            -k `
            -X PUT `
            "https://$IP/api/v1/files/cliScript/incremental" `
            -H "Authorization: Basic $cred_encoded" `
            -F "file=@$CliFile;type=application/octet-stream"

        # ----------------------------
        # Save Configuration
        # ----------------------------

        Write-Host "[$DeviceName] Saving configuration..." -ForegroundColor Cyan

        $SaveResponse = curl.exe `
            -s `
            -k `
            -X POST `
            "https://$IP/api/v1/actions/saveConfiguration" `
            -H "Authorization: Basic $cred_encoded" `
            -H "Content-Type: application/json" `
            -d "{}"

        # ----------------------------
        # Success Log
        # ----------------------------

@"
====================================================
Execution Time : $(Get-Date)

Device Name    : $DeviceName
IP Address     : $IP
Username       : $NewUsername

====================================================

CLI PAYLOAD SENT
====================================================

$cliScript

====================================================
CREATE USER RESPONSE
====================================================

$CreateResponse

====================================================
SAVE CONFIG RESPONSE
====================================================

$SaveResponse

====================================================
STATUS : SUCCESS
====================================================

"@ | Out-File `
        -FilePath $LogFile `
        -Encoding UTF8

        $Results += [PSCustomObject]@{
            DeviceName = $DeviceName
            IP         = $IP
            Status     = "Success"
            Error      = ""
            Timestamp  = Get-Date
        }

        Write-Host "[$DeviceName] SUCCESS" -ForegroundColor Green
    }
    catch
    {
        $ErrorMessage = $_.Exception.Message

@"
====================================================
Execution Time : $(Get-Date)

Device Name    : $DeviceName
IP Address     : $IP
Username       : $NewUsername

====================================================
CLI PAYLOAD
====================================================

$cliScript

====================================================
ERROR
============================================$ErrorMessage

====================================================
STATUS : FAILED
====================================================

"@ | Out-File `
        -FilePath $LogFile `
        -Encoding UTF8

        $Results += [PSCustomObject]@{
            DeviceName = $DeviceName
            IP         = $IP
            Status     = "Failed"
            Error      = $ErrorMessage
            Timestamp  = Get-Date
        }

        Write-Host "[$DeviceName] FAILED - $ErrorMessage" -ForegroundColor Red
    }
    finally
    {
        Remove-Item `
            $CliFile `
            -Force `
            -ErrorAction SilentlyContinue
    }
}

# ----------------------------
# Export Summary
# ----------------------------

$Results | Export-Csv `
    -Path $ReportFile `
    -NoTypeInformation

# ----------------------------
# Statistics
# ----------------------------

$Success = ($Results | Where-Object Status -eq "Success").Count
$Failed  = ($Results | Where-Object Status -eq "Failed").Count

Write-Host ""
Write-Host "==========================================" -ForegroundColor Cyan
Write-Host "Execution Completed"
Write-Host "==========================================" -ForegroundColor Cyan
Write-Host "Success : $Success" -ForegroundColor Green
Write-Host "Failed  : $Failed" -ForegroundColor Red
Write-Host "Report  : $ReportFile"
Write-Host "Logs    : $LogFolder"
Write-Host "==========================================" -ForegroundColor Cyan